#!/usr/bin/env bash
set -euo pipefail

# Manual launcher for SDT-BOT-V1.
# Run from the extracted project directory:
#   sudo ./start-bot.sh

cd "$(dirname "${BASH_SOURCE[0]}")"

if [[ "${EUID}" -ne 0 ]]; then
  echo "ERROR: run the bot manually as root: sudo ./start-bot.sh" >&2
  exit 1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"
command -v "$PYTHON_BIN" >/dev/null 2>&1 || {
  echo "ERROR: Python 3 is required. Run sudo bash install-host.sh first." >&2
  exit 1
}

# Ensure the venv module exists instead of failing later with a cryptic error.
if ! "$PYTHON_BIN" -m venv --help >/dev/null 2>&1; then
  echo "ERROR: python3-venv is missing. Run: sudo apt-get update && sudo apt-get install -y python3-venv" >&2
  exit 1
fi

if [[ ! -x .venv/bin/python ]]; then
  echo "[SDT] Creating Python virtual environment..."
  "$PYTHON_BIN" -m venv .venv
fi

VENV_PY="$(pwd)/.venv/bin/python"
VENV_PIP="$(pwd)/.venv/bin/pip"

# Always install into the exact interpreter that launches bot.py.
echo "[SDT] Installing/updating Python dependencies..."
"$VENV_PY" -m pip install --disable-pip-version-check --upgrade pip
"$VENV_PIP" install --disable-pip-version-check -r requirements.txt

# Fail early with a useful message rather than 'Fatal module not found'.
"$VENV_PY" -c 'import discord; print("[SDT] discord.py OK:", discord.__version__)'

echo "[SDT] Starting bot manually. Press Ctrl+C to stop."
exec "$VENV_PY" bot.py
