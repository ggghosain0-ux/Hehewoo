# SDT-BOT-V1 — Admin-Only LXC VPS Deployer

This version uses **`bot.py` only**. `bot2.py` is not used.

## Manual bot startup

The bot is intentionally started **manually**. There is no systemd service or automatic bot startup.

After extracting the project:

```bash
cd SDT-BOT-V1-LXC-fixed-v3
sudo bash install-host.sh
sudo ./start-bot.sh
```

`start-bot.sh` creates `.venv` if needed, installs `requirements.txt` into that exact virtual environment, verifies `discord.py` can be imported, and then launches `bot.py` with the same interpreter. This prevents the common `ModuleNotFoundError: No module named 'discord'` caused by using a different Python/pip environment.

To stop the bot, press **Ctrl+C**. To start it again, run:

```bash
sudo ./start-bot.sh
```

If `python3-venv` is missing, the launcher prints the exact package-install command instead of failing with a module error.

## Core rule

**Only administrators can create VPSs.** A normal Discord user cannot create a VPS and cannot select RAM, CPU, disk, or OS.

The administrator decides all VPS resources when creating it:

```text
$create <RAM> <CPU> <DISK> <OS> <@USER>
```

Example:

```text
$create 2G 2 20G ubuntu22.04 @User
```

That creates a VPS with exactly:

- 2 GB RAM limit
- 2 CPU cores limit
- 20 GB fixed EXT4 root disk
- Ubuntu 22.04
- SSH
- Tailscale

Docker is used **only as an OS image importer**. The running VPS is an LXC container.

## User commands

```text
$myvps
$info <id>
$start <id>
$stop <id>
$restart <id>
$exec <id> <command>
$deletevps <id>
$ping
$about
```

## Admin commands

```text
$create <RAM> <CPU> <DISK> <OS> <@USER>
$list
$system
$renewlink <id>
```

Discord users with the Administrator permission or IDs in `ADMIN_IDS` can use admin commands.

## Supported OS images

```text
ubuntu:22.04
ubuntu:24.04
debian:12
debian:13
```

The bot first checks whether the Docker image exists locally. If it does not, it pulls the image from Docker Hub, exports its filesystem, and places it into the fixed-size EXT4 LXC root filesystem.

## Deployment behavior

LXC is considered deployed once it reaches **RUNNING**. SSH/package setup and Tailscale continue automatically. A slow SSH/Tailscale setup therefore does not incorrectly report the VPS as failed.

If LXC itself fails to start, the bot reports the LXC startup log so the actual failure can be diagnosed.

Static VPS IPs use `10.0.3.200-254`; DHCP uses `10.0.3.2-199`.

## Tailscale

Each VPS receives `/dev/net/tun`, starts `tailscaled`, and generates a Tailscale login URL. The login URL and SSH credentials are DM'd to the assigned user.

## Important LXC limitation

LXC shares the host Linux kernel. Therefore `uname -r` can still show the host kernel. LXC provides process, CPU, memory, network and filesystem isolation, but it is not a full hardware VM such as KVM/QEMU.

## Security

Do not publish `config.json`, `vps_db.json`, or your Discord bot token.
