import asyncio
import json
import logging
import os
import re
import secrets
import shutil
import string
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import discord
from discord.ext import commands

BASE = Path(__file__).resolve().parent
CFG = BASE / "config.json"
DB = BASE / "vps_db.json"
LOG = BASE / "bot.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler(LOG), logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("SDT-BOT-V1")

DEFAULT = {
    "TOKEN": "YOUR_DISCORD_BOT_TOKEN_HERE",
    "PREFIX": "$",
    "ADMIN_IDS": [],
    "LXC_DIR": "/var/lib/lxc",
    "IMAGE_DIR": "/var/lib/sdt-bot/images",
    "BRIDGE": "lxcbr0",
    "NETWORK": "10.0.3.0/24",
    "GATEWAY": "10.0.3.1",
    "SUPPORTED_OS": ["ubuntu:22.04", "ubuntu:24.04", "debian:12", "debian:13"],
    "MAX_CREATE_MINUTES": 20,
}

if not CFG.exists():
    CFG.write_text(json.dumps(DEFAULT, indent=4))
    raise SystemExit("config.json created. Set TOKEN and ADMIN_IDS, then restart.")

try:
    config = {**DEFAULT, **json.loads(CFG.read_text())}
except Exception as exc:
    raise SystemExit(f"Invalid config.json: {exc}")

PFX = str(config["PREFIX"])
LXC_DIR = Path(config["LXC_DIR"])
IMAGE_DIR = Path(config["IMAGE_DIR"])
BRIDGE = str(config["BRIDGE"])
GATEWAY = str(config["GATEWAY"])

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PFX, intents=intents, help_command=None)


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(json.dumps(data, indent=4))
    tmp.replace(path)


def load_db():
    if not DB.exists():
        data = {"vps": {}, "admins": [int(x) for x in config.get("ADMIN_IDS", [])]}
        write_json(DB, data)
        return data
    try:
        data = json.loads(DB.read_text())
    except Exception:
        corrupt = DB.with_suffix(".corrupt.json")
        try:
            shutil.copy2(DB, corrupt)
        except Exception:
            pass
        data = {"vps": {}, "admins": [int(x) for x in config.get("ADMIN_IDS", [])]}
    data.setdefault("vps", {})
    data.setdefault("admins", [int(x) for x in config.get("ADMIN_IDS", [])])
    return data


def save_db(data):
    write_json(DB, data)


def cmd(args, timeout=60, check=True):
    args = [str(x) for x in args]
    try:
        p = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"Command timed out after {timeout}s: {' '.join(args)}") from exc
    if check and p.returncode != 0:
        detail = (p.stderr or p.stdout or "unknown error").strip()
        raise RuntimeError(f"{' '.join(args)} failed: {detail[-1800:]}")
    return p


def exists(binary):
    return shutil.which(binary) is not None


def host_check():
    if os.geteuid() != 0:
        raise RuntimeError("Run the bot as root (sudo).")
    required = [
        "lxc-create", "lxc-start", "lxc-stop", "lxc-info", "lxc-attach",
        "lxc-destroy", "docker", "mount", "umount", "fallocate", "mkfs.ext4",
    ]
    missing = [x for x in required if not exists(x)]
    if missing:
        raise RuntimeError("Missing host commands: " + ", ".join(missing))
    if not Path("/dev/net/tun").exists():
        raise RuntimeError("/dev/net/tun is missing. Run install-host.sh first.")
    if not cmd(["ip", "link", "show", BRIDGE], 15, False).returncode == 0:
        raise RuntimeError(f"LXC bridge {BRIDGE} does not exist. Run install-host.sh first.")


def parse_size(value, minimum=256 * 1024**2):
    match = re.fullmatch(r"\s*(\d+)\s*([mMgGtT])(?:[bB])?\s*", str(value))
    if not match:
        raise ValueError("Use sizes such as 512M, 2G, 20G.")
    number = int(match.group(1))
    unit = match.group(2).lower()
    multiplier = {"m": 2**20, "g": 2**30, "t": 2**40}[unit]
    result = number * multiplier
    if result < minimum:
        raise ValueError("Requested disk/RAM size is below the minimum allowed value.")
    return result


def fmt_bytes(value):
    value = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TiB"


def normalize_os(value):
    x = re.sub(r"[^a-z0-9:.+_-]", "", str(value).lower())
    aliases = {
        "ubuntu2204": "ubuntu:22.04", "ubuntu22.04": "ubuntu:22.04",
        "ubuntu2404": "ubuntu:24.04", "ubuntu24.04": "ubuntu:24.04",
        "debian12": "debian:12", "debian13": "debian:13",
    }
    x = aliases.get(x, x)
    if x not in config["SUPPORTED_OS"]:
        raise ValueError("Supported OS: " + ", ".join(config["SUPPORTED_OS"]))
    return x


def random_password(length=20):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def container_name(owner_id):
    return f"sdt-{owner_id}-{secrets.token_hex(4)}"


def lxc_attach(name, command, timeout=120, check=True):
    return cmd(["lxc-attach", "-n", name, "--"] + command, timeout, check)


def is_running(name):
    return "RUNNING" in cmd(["lxc-info", "-n", name, "-s"], 15, False).stdout


def is_present(name):
    return cmd(["lxc-info", "-n", name], 15, False).returncode == 0


def destroy_container(name):
    if not name:
        return
    if is_present(name):
        if is_running(name):
            cmd(["lxc-stop", "-n", name, "-k"], 90, False)
        cmd(["lxc-destroy", "-n", name], 120, False)


INIT_SCRIPT = r'''#!/bin/bash
set -u
export DEBIAN_FRONTEND=noninteractive
mkdir -p /run/sshd /run/tailscale /var/lib/tailscale /var/log/sdt

apt-get update -y >/var/log/sdt/apt-update.log 2>&1 || true
apt-get install -y --no-install-recommends openssh-server curl ca-certificates procps iproute2 iputils-ping sudo >/var/log/sdt/base-packages.log 2>&1 || true

if ! command -v tailscale >/dev/null 2>&1; then
    curl -fsSL https://tailscale.com/install.sh | sh >/var/log/sdt/tailscale-install.log 2>&1 || true
fi

if ! command -v neofetch >/dev/null 2>&1; then
    apt-get install -y neofetch >/var/log/sdt/neofetch-install.log 2>&1 || true
fi
if ! command -v neofetch >/dev/null 2>&1; then
cat >/usr/local/bin/neofetch <<'NEO'
#!/bin/bash
echo '----------------------------'
echo '       SDT LXC VPS'
echo '----------------------------'
echo "OS:       $(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-Linux}")"
echo "Kernel:   $(uname -r)"
echo "Hostname: $(hostname)"
echo "CPU:      $(nproc 2>/dev/null || echo unknown)"
echo "Memory:   $(awk '/MemTotal/ {printf "%.0f MiB\n",$2/1024}' /proc/meminfo 2>/dev/null)"
echo "Disk:     $(df -h / 2>/dev/null | awk 'NR==2 {print $3 " / " $2}')"
echo "Tailscale: $(tailscale ip -4 2>/dev/null || echo offline)"
echo '----------------------------'
NEO
chmod +x /usr/local/bin/neofetch
fi

sed -ri 's/^[#[:space:]]*PermitRootLogin .*/PermitRootLogin yes/' /etc/ssh/sshd_config 2>/dev/null || true
sed -ri 's/^[#[:space:]]*PasswordAuthentication .*/PasswordAuthentication yes/' /etc/ssh/sshd_config 2>/dev/null || true
grep -q '^PermitRootLogin' /etc/ssh/sshd_config 2>/dev/null || echo 'PermitRootLogin yes' >>/etc/ssh/sshd_config
grep -q '^PasswordAuthentication' /etc/ssh/sshd_config 2>/dev/null || echo 'PasswordAuthentication yes' >>/etc/ssh/sshd_config

if [ -f /etc/sdt-root-password ]; then
    echo "root:$(cat /etc/sdt-root-password)" | chpasswd || true
    rm -f /etc/sdt-root-password
fi

ssh-keygen -A >/dev/null 2>&1 || true
pkill -x sshd 2>/dev/null || true
/usr/sbin/sshd >/var/log/sdt/sshd.log 2>&1 || true

pkill -x tailscaled 2>/dev/null || true
if command -v tailscaled >/dev/null 2>&1; then
    tailscaled --state=/var/lib/tailscale/tailscaled.state --socket=/run/tailscale/tailscaled.sock >/var/log/sdt/tailscaled.log 2>&1 &
    for i in $(seq 1 45); do
        [ -S /run/tailscale/tailscaled.sock ] && break
        sleep 1
    done
    if [ -S /run/tailscale/tailscaled.sock ]; then
        tailscale --socket=/run/tailscale/tailscaled.sock set --accept-dns=false >/dev/null 2>&1 || true
        if ! tailscale --socket=/run/tailscale/tailscaled.sock status >/dev/null 2>&1; then
            rm -f /var/lib/tailscale/login-url /var/lib/tailscale/up-output
            timeout 60 tailscale --socket=/run/tailscale/tailscaled.sock up --accept-dns=false --hostname="${SDT_HOSTNAME:-$(hostname)}" >/var/lib/tailscale/up-output 2>&1 || true
            grep -Eo 'https://login\.tailscale\.com/[A-Za-z0-9/_?=&.%-]+' /var/lib/tailscale/up-output | head -n1 >/var/lib/tailscale/login-url || true
        fi
    fi
fi

touch /run/sdt/ready
exec /bin/sh -c 'while true; do sleep 3600; done'
'''


def docker_export(image, work_dir):
    if not exists("docker"):
        raise RuntimeError("Docker is required only for importing Docker Hub/local OS images.")
    if cmd(["docker", "image", "inspect", image], 30, False).returncode != 0:
        cmd(["docker", "pull", image], 900)
    cname = "sdt-import-" + secrets.token_hex(5)
    tar_path = Path(work_dir) / "rootfs.tar"
    try:
        cmd(["docker", "create", "--name", cname, image], 120)
        with tar_path.open("wb") as output:
            proc = subprocess.run(["docker", "export", cname], stdout=output, stderr=subprocess.PIPE, timeout=900)
        if proc.returncode != 0:
            raise RuntimeError("docker export failed: " + proc.stderr.decode(errors="replace")[-1600:])
        return tar_path
    finally:
        cmd(["docker", "rm", "-f", cname], 60, False)


def make_ext4(path, bytes_size):
    path.parent.mkdir(parents=True, exist_ok=True)
    cmd(["fallocate", "-l", bytes_size, path], 120)
    cmd(["mkfs.ext4", "-F", "-m", "0", path], 180)


def seed_rootfs(disk_path, image, name, password):
    work = IMAGE_DIR / "work" / name
    root = work / "root"
    root.mkdir(parents=True, exist_ok=True)
    cmd(["mount", "-o", "loop", disk_path, root], 60)
    try:
        tar = docker_export(image, work)
        cmd(["tar", "-xf", tar, "-C", root], 900)
        for item in (root / "etc/hostname", root / "etc/hosts", root / "etc/resolv.conf"):
            try:
                item.unlink()
            except FileNotFoundError:
                pass
        (root / "etc/hostname").write_text(name + "\n")
        (root / "etc/hosts").write_text(f"127.0.0.1 localhost\n127.0.1.1 {name}\n")
        (root / "etc/resolv.conf").write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        sdt = root / "opt/sdt"
        sdt.mkdir(parents=True, exist_ok=True)
        (sdt / "init.sh").write_text(INIT_SCRIPT)
        (sdt / "init.sh").chmod(0o755)
        (root / "etc/sdt-root-password").write_text(password + "\n")
    finally:
        cmd(["umount", "-l", root], 60, False)
        shutil.rmtree(work, ignore_errors=True)


def allocate_ip():
    used = set()
    for vps in load_db().get("vps", {}).values():
        if vps.get("ip"):
            used.add(vps["ip"])
    for last in range(2, 255):
        candidate = f"10.0.3.{last}"
        if candidate not in used:
            return candidate
    raise RuntimeError("No free LXC bridge IP addresses remain.")


def write_lxc_config(name, disk, ram_bytes, cpu_count, ip):
    directory = LXC_DIR / name
    directory.mkdir(parents=True, exist_ok=True)
    config_text = f'''lxc.arch = linux64
lxc.uts.name = {name}
lxc.rootfs.path = loop:{disk}
lxc.mount.auto = proc:mixed sys:ro cgroup:mixed
lxc.net.0.type = veth
lxc.net.0.link = {BRIDGE}
lxc.net.0.flags = up
lxc.net.0.name = eth0
lxc.net.0.hwaddr = 00:16:3e:{secrets.token_hex(3)}
lxc.net.0.ipv4.address = {ip}/24
lxc.net.0.ipv4.gateway = {GATEWAY}
lxc.start.auto = 0
lxc.cgroup2.memory.max = {ram_bytes}
lxc.cgroup2.memory.swap.max = {ram_bytes}
lxc.cgroup2.cpu.max = {cpu_count * 100000} 100000
lxc.apparmor.profile = unconfined
lxc.cap.drop =
lxc.cgroup2.devices.allow = c 10:200 rwm
lxc.mount.entry = /dev/net/tun dev/net/tun none bind,create=file
lxc.autodev = 1
lxc.init.cmd = /opt/sdt/init.sh
'''
    (directory / "config").write_text(config_text)


def boot_container(name):
    cmd(["lxc-start", "-n", name, "-d"], 90)
    deadline = time.time() + 180
    while time.time() < deadline:
        if is_running(name):
            ready = lxc_attach(name, ["bash", "-lc", "test -f /run/sdt/ready"], 10, False)
            if ready.returncode == 0:
                return
        time.sleep(2)
    raise RuntimeError("LXC did not finish booting. Check the container log with the admin exec command.")


def tailscale_login_url(name):
    deadline = time.time() + 120
    while time.time() < deadline:
        result = lxc_attach(name, ["bash", "-lc", "cat /var/lib/tailscale/login-url 2>/dev/null || true"], 20, False)
        match = re.search(r"https://login\.tailscale\.com/[A-Za-z0-9/_?=&.%-]+", result.stdout or "")
        if match:
            return match.group(0)
        time.sleep(2)
    logs = lxc_attach(name, ["bash", "-lc", "tail -n 80 /var/log/sdt/tailscaled.log 2>/dev/null || true"], 20, False)
    raise RuntimeError("Tailscale login URL was not generated:\n" + (logs.stdout or "")[-1400:])


def tailscale_ip(name):
    result = lxc_attach(name, ["bash", "-lc", "tailscale ip -4 2>/dev/null || true"], 20, False)
    match = re.search(r"\b100\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", result.stdout or "")
    return match.group(0) if match else None


def provision(image, ram, cpu, disk, owner_id):
    host_check()
    LXC_DIR.mkdir(parents=True, exist_ok=True)
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    name = container_name(owner_id)
    disk_path = IMAGE_DIR / f"{name}.ext4"
    ip = allocate_ip()
    password = random_password()
    try:
        free = shutil.disk_usage(IMAGE_DIR).free
        if free < disk + 512 * 1024**2:
            raise RuntimeError(f"Not enough host disk space. Need at least {fmt_bytes(disk + 512 * 1024**2)} free.")
        make_ext4(disk_path, disk)
        seed_rootfs(disk_path, image, name, password)
        write_lxc_config(name, disk_path, ram, cpu, ip)
        boot_container(name)
        url = tailscale_login_url(name)
        return {
            "name": name,
            "disk_image": str(disk_path),
            "ip": ip,
            "tailscale_ip": tailscale_ip(name),
            "login_url": url,
            "password": password,
        }
    except Exception:
        destroy_container(name)
        disk_path.unlink(missing_ok=True)
        raise


# ---------------- Discord permissions ----------------


def is_admin(ctx):
    admins = {int(x) for x in load_db().get("admins", [])}
    return ctx.author.id in admins or bool(getattr(ctx.author.guild_permissions, "administrator", False))


def admin_only():
    async def predicate(ctx):
        if is_admin(ctx):
            return True
        await ctx.reply("❌ Only the VPS administrator can create/manage VPSs.", mention_author=False)
        return False
    return commands.check(predicate)


def owned_vps(ctx):
    return [(vid, v) for vid, v in load_db()["vps"].items() if int(v["owner_id"]) == ctx.author.id]


@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)


@bot.command()
async def ping(ctx):
    await ctx.reply(f"🏓 `{round(bot.latency * 1000)}ms`", mention_author=False)


@bot.command()
async def about(ctx):
    await ctx.reply("🚀 **SDT-BOT-V1** — Admin-created LXC VPS with fixed RAM/CPU/disk limits, SSH and Tailscale.", mention_author=False)


@bot.command(name="create", aliases=["createvps", "newvps"])
@admin_only()
async def create(ctx, ram: str, cpu: int, disk: str, os_type: str, user: discord.Member):
    """ADMIN ONLY: $create <RAM> <CPU> <DISK> <OS> @USER"""
    try:
        if not 1 <= cpu <= 128:
            raise ValueError("CPU must be between 1 and 128 cores.")
        ram_bytes = parse_size(ram, 256 * 1024**2)
        disk_bytes = parse_size(disk, 1 * 1024**3)
        image = normalize_os(os_type)
    except (ValueError, commands.BadArgument) as exc:
        await ctx.reply("❌ " + str(exc), mention_author=False)
        return

    message = await ctx.send(
        f"⏳ **Admin VPS deployment started**\nUser: {user.mention}\nOS: `{image}` • RAM: `{ram}` • CPU: `{cpu}` • Disk: `{disk}`"
    )
    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(provision, image, ram_bytes, cpu, disk_bytes, user.id),
            timeout=int(config["MAX_CREATE_MINUTES"]) * 60,
        )
        vps_id = result["name"].removeprefix("sdt-")
        data = load_db()
        data["vps"][vps_id] = {
            **result,
            "owner_id": user.id,
            "owner_tag": str(user),
            "ram": ram,
            "cpu": cpu,
            "disk": disk,
            "os": image,
            "status": "RUNNING",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        save_db(data)

        embed = discord.Embed(title="🚀 Your VPS is Ready", color=discord.Color.green())
        fields = [
            ("VPS ID", vps_id), ("OS", image), ("CPU", f"{cpu} cores"),
            ("RAM", ram), ("Disk", disk), ("LXC IP", result["ip"]),
            ("Tailscale IPv4", result["tailscale_ip"] or "Authenticate first"),
        ]
        for key, value in fields:
            embed.add_field(name=key, value=f"`{value}`", inline=True)
        embed.add_field(name="🔗 Tailscale Login", value=result["login_url"], inline=False)
        embed.add_field(
            name="🔐 SSH",
            value=f"Username: `root`\nPassword: `{result['password']}`\nPort: `22`\n\nAfter authentication: `ssh root@{result['tailscale_ip'] or '<tailscale-ip>'}`",
            inline=False,
        )
        embed.set_footer(text="Resources were selected and enforced by the administrator.")

        try:
            await user.send(embed=embed)
        except discord.Forbidden:
            destroy_container(result["name"])
            Path(result["disk_image"]).unlink(missing_ok=True)
            data["vps"].pop(vps_id, None)
            save_db(data)
            await message.edit(content=f"❌ Deployment rolled back because {user.mention} has DMs disabled.")
            return

        await message.edit(content=f"✅ VPS `{vps_id}` created for {user.mention}. Credentials and Tailscale link were sent by DM.")
    except Exception as exc:
        log.exception("VPS creation failed")
        await message.edit(content=f"❌ **VPS deployment failed**\n```text\n{str(exc)[:1800]}\n```")


@bot.command()
async def myvps(ctx):
    items = owned_vps(ctx)
    if not items:
        await ctx.reply("❌ You do not have a VPS.", mention_author=False)
        return
    lines = []
    for vid, v in items:
        status = "RUNNING" if is_running(v["name"]) else "STOPPED"
        lines.append(f"`{vid}` • {v['os']} • {v['ram']} • {v['cpu']} CPU • {v['disk']} • `{status}`")
    await ctx.reply("🖥️ **Your VPSs**\n" + "\n".join(lines)[:1900], mention_author=False)


@bot.command()
async def info(ctx, vid: str):
    v = load_db()["vps"].get(vid)
    if not v or (int(v["owner_id"]) != ctx.author.id and not is_admin(ctx)):
        await ctx.reply("❌ VPS not found or access denied.", mention_author=False)
        return
    status = "RUNNING" if is_running(v["name"]) else "STOPPED"
    await ctx.reply(
        f"🖥️ **{vid}**\nOS: `{v['os']}`\nCPU: `{v['cpu']}`\nRAM: `{v['ram']}`\nDisk: `{v['disk']}`\nLXC IP: `{v.get('ip', 'unknown')}`\nStatus: `{status}`\nTailscale: `{v.get('tailscale_ip') or 'offline'}`",
        mention_author=False,
    )


async def control_vps(ctx, vid, action):
    v = load_db()["vps"].get(vid)
    if not v or (int(v["owner_id"]) != ctx.author.id and not is_admin(ctx)):
        await ctx.reply("❌ VPS not found or access denied.", mention_author=False)
        return
    try:
        if action == "start":
            if not is_running(v["name"]):
                cmd(["lxc-start", "-n", v["name"], "-d"], 90)
        elif action == "stop":
            if is_running(v["name"]):
                cmd(["lxc-stop", "-n", v["name"]], 90)
        elif action == "restart":
            if is_running(v["name"]):
                cmd(["lxc-stop", "-n", v["name"]], 90)
                time.sleep(2)
            cmd(["lxc-start", "-n", v["name"], "-d"], 90)
        await ctx.reply(f"✅ `{action}` completed for `{vid}`.", mention_author=False)
    except Exception as exc:
        await ctx.reply("❌ " + str(exc)[:1800], mention_author=False)


@bot.command()
async def start(ctx, vid: str):
    await control_vps(ctx, vid, "start")


@bot.command()
async def stop(ctx, vid: str):
    await control_vps(ctx, vid, "stop")


@bot.command()
async def restart(ctx, vid: str):
    await control_vps(ctx, vid, "restart")


@bot.command()
async def deletevps(ctx, vid: str):
    data = load_db()
    v = data["vps"].get(vid)
    if not v or (int(v["owner_id"]) != ctx.author.id and not is_admin(ctx)):
        await ctx.reply("❌ VPS not found or access denied.", mention_author=False)
        return
    try:
        destroy_container(v["name"])
        Path(v.get("disk_image", "")).unlink(missing_ok=True)
        data["vps"].pop(vid, None)
        save_db(data)
        await ctx.reply(f"🗑️ VPS `{vid}` deleted.", mention_author=False)
    except Exception as exc:
        await ctx.reply("❌ Delete failed: " + str(exc)[:1500], mention_author=False)


@bot.command(name="exec", aliases=["console"])
async def exec_command(ctx, vid: str, *, command: str):
    data = load_db()
    v = data["vps"].get(vid)
    if not v or int(v["owner_id"]) != ctx.author.id:
        await ctx.reply("❌ VPS not found or access denied.", mention_author=False)
        return
    if not is_running(v["name"]):
        await ctx.reply("❌ VPS is stopped.", mention_author=False)
        return
    if len(command) > 1200:
        await ctx.reply("❌ Command is too long.", mention_author=False)
        return
    result = lxc_attach(v["name"], ["bash", "-lc", command], 120, False)
    output = ((result.stdout or "") + ("\n" + result.stderr if result.stderr else "")).strip() or "(no output)"
    await ctx.reply("```text\n" + output[:1800].replace("```", "~~~") + "\n```", mention_author=False)


@bot.command()
@admin_only()
async def list(ctx):
    data = load_db()
    lines = []
    for vid, v in data["vps"].items():
        status = "RUNNING" if is_running(v["name"]) else "STOPPED"
        lines.append(f"`{vid}` • <@{v['owner_id']}> • {v['os']} • {v['ram']} RAM • {v['cpu']} CPU • {v['disk']} • `{status}`")
    await ctx.reply("📋 **All VPSs**\n" + ("\n".join(lines)[:1900] if lines else "No VPSs."), mention_author=False)


@bot.command()
@admin_only()
async def system(ctx):
    usage = shutil.disk_usage("/")
    await ctx.reply(
        f"🖥️ **Host**\nCPU: `{os.cpu_count()}`\nDisk: `{fmt_bytes(usage.used)} / {fmt_bytes(usage.total)}`\nFree: `{fmt_bytes(usage.free)}`\nBridge: `{BRIDGE}`\nTUN: `{Path('/dev/net/tun').exists()}`",
        mention_author=False,
    )


@bot.command()
@admin_only()
async def renewlink(ctx, vid: str):
    v = load_db()["vps"].get(vid)
    if not v:
        await ctx.reply("❌ VPS not found.", mention_author=False)
        return
    try:
        url = await asyncio.to_thread(tailscale_login_url, v["name"])
        await ctx.reply(f"🔗 Tailscale login URL for `{vid}`:\n{url}", mention_author=False)
    except Exception as exc:
        await ctx.reply("❌ " + str(exc)[:1700], mention_author=False)


@bot.command()
async def help(ctx):
    await ctx.reply(
        f"**SDT-BOT-V1 — Admin VPS Deployer**\n\n"
        f"**User:**\n"
        f"`{PFX}myvps`\n`{PFX}info <id>`\n`{PFX}start <id>`\n`{PFX}stop <id>`\n`{PFX}restart <id>`\n`{PFX}exec <id> <command>`\n`{PFX}deletevps <id>`\n`{PFX}ping`\n\n"
        f"**ADMIN ONLY:**\n"
        f"`{PFX}create <ram> <cpu> <disk> <os> <@user>`\n"
        f"Example: `{PFX}create 2G 2 20G ubuntu22.04 @User`\n"
        f"`{PFX}list` `{PFX}system` `{PFX}renewlink <id>`\n\n"
        f"⚠️ Users cannot create VPSs or choose their VPS resources. The administrator defines RAM, CPU, disk and OS.",
        mention_author=False,
    )


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, (commands.CommandNotFound, commands.CheckFailure)):
        return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.reply(f"❌ Missing argument. Use `{PFX}help`.", mention_author=False)
        return
    if isinstance(error, commands.BadArgument):
        await ctx.reply(f"❌ Invalid argument. Use `{PFX}help`.", mention_author=False)
        return
    log.exception("Command error", exc_info=error)
    await ctx.reply(f"❌ {str(error)[:1500]}", mention_author=False)


if __name__ == "__main__":
    if str(config.get("TOKEN", "")).startswith("YOUR_"):
        raise SystemExit("Set TOKEN in config.json before starting the bot.")
    try:
        host_check()
    except Exception as exc:
        log.warning("Host preflight: %s", exc)
    bot.run(config["TOKEN"])
