# SDT-BOT-V1 — Admin-Only LXC VPS Deployer

This version uses **`bot.py` only**. `bot2.py` is not used.

## Core rule

**Only administrators can create VPSs.** A normal Discord user cannot create a VPS and cannot select RAM, CPU, disk, or OS.

The administrator decides all VPS resources when creating it:

```text
$create <RAM> <CPU> <DISK> <OS> <@USER>
```

Example:

```text
$create 2G 2 20G ubuntu22.04 @User
```

That creates a VPS with exactly:

- 2 GB RAM limit
- 2 CPU cores limit
- 20 GB fixed EXT4 root disk
- Ubuntu 22.04
- SSH
- Tailscale

Docker is used **only as an OS image importer**. The running VPS is an LXC container.

## User commands

```text
$myvps
$info <id>
$start <id>
$stop <id>
$restart <id>
$exec <id> <command>
$deletevps <id>
$ping
$about
```

## Admin commands

```text
$create <RAM> <CPU> <DISK> <OS> <@USER>
$list
$system
$renewlink <id>
```

Discord users with the Administrator permission or IDs in `ADMIN_IDS` can use admin commands.

## Supported OS images

```text
ubuntu:22.04
ubuntu:24.04
debian:12
debian:13
```

The bot first checks whether the Docker image exists locally. If it does not, it pulls the image from Docker Hub, exports its filesystem, and places it into the fixed-size EXT4 LXC root filesystem.

## Tailscale

Each VPS receives `/dev/net/tun`, starts `tailscaled`, and generates a Tailscale login URL. The login URL and SSH credentials are DM'd to the assigned user.

## Important LXC limitation

LXC shares the host Linux kernel. Therefore `uname -r` can still show the host kernel. LXC provides process, CPU, memory, network and filesystem isolation, but it is not a full hardware VM such as KVM/QEMU.

## Installation

Run on a supported Linux host as root:

```bash
sudo bash install-host.sh
```

Then configure `config.json` and install the Python dependency:

```bash
python3 -m pip install --break-system-packages -r requirements.txt
```

Start:

```bash
sudo python3 bot.py
```

Do not publish `config.json`, `vps_db.json`, or your Discord bot token.
