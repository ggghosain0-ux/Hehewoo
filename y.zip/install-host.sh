#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run as root: sudo bash install-host.sh"; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y lxc lxc-utils lxc-templates lxcfs bridge-utils dnsmasq-base iproute2 iptables curl ca-certificates docker.io python3 python3-pip
systemctl enable --now docker || true
modprobe tun || true
mkdir -p /dev/net
[[ -e /dev/net/tun ]] || mknod /dev/net/tun c 10 200
chmod 0666 /dev/net/tun
cat >/etc/default/lxc-net <<'EOF'
USE_LXC_BRIDGE="true"
LXC_BRIDGE="lxcbr0"
LXC_ADDR="10.0.3.1"
LXC_NETMASK="255.255.255.0"
LXC_NETWORK="10.0.3.0/24"
LXC_DHCP_RANGE="10.0.3.2,10.0.3.254"
LXC_DHCP_MAX="253"
EOF
sysctl -w net.ipv4.ip_forward=1
cat >/etc/sysctl.d/99-sdt-lxc.conf <<'EOF'
net.ipv4.ip_forward=1
EOF
systemctl enable --now lxc-net 2>/dev/null || true
systemctl restart lxc-net 2>/dev/null || true
mkdir -p /var/lib/sdt-bot/images
chmod 755 /var/lib/sdt-bot /var/lib/sdt-bot/images
echo "Host preparation complete."
